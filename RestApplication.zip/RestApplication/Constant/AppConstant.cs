﻿namespace RestApplication.Constant
{
    public static class AppConstant
    {
        public const decimal TAXRATE = 0.18m;
    }
}